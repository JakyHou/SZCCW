#ifndef __TARGET_H__
#define __TARGET_H__

#ifdef __cplusplus
extern "C"
{
#endif

// Nuvoton MCU Peripheral Access Layer Header File
#include "NM1120.h"


#ifdef __cplusplus
}
#endif

#endif //__TARGET_H__
