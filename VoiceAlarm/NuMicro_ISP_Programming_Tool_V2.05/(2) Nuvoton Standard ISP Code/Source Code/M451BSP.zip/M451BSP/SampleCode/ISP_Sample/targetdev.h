
#include "M451Series.h"
#include "isp_user.h"
#include "ISP_HID\hid_transfer.h"

#define DetectPin   PB6
