
#include "M4521.h"
#include "isp_user.h"
#include "ISP_HID\hid_transfer.h"

#define DetectPin   PD0
