
#include "NUC230_240.h"
#include "hid_transfer.h"
#include "isp_user.h"

#define DetectPin   				PA10
