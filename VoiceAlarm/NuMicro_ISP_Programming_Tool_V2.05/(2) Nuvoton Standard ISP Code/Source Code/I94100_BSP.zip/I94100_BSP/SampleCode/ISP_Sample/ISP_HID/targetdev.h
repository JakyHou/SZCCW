#ifndef __TARGET_H__
#define __TARGET_H__

#ifdef __cplusplus
extern "C"
{
#endif

// Nuvoton MCU Peripheral Access Layer Header File
#include "I94100.h"
#include "hid_trans.h"
#include "isp_user.h"
#define DetectPin   				PD2

#ifdef __cplusplus
}
#endif

#endif //__TARGET_H__
