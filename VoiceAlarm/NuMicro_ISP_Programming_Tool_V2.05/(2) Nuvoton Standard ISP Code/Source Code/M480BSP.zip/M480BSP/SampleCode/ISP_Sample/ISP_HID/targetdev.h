#ifndef __TARGET_H__
#define __TARGET_H__

#ifdef __cplusplus
extern "C"
{
#endif

// Nuvoton MCU Peripheral Access Layer Header File
#include "M480.h"
#include "isp_user.h"
#define DetectPin   				PB12

#ifdef __cplusplus
}
#endif

#endif //__TARGET_H__
