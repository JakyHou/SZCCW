
#include "NUC121.h"
#include "hid_transfer.h"
#include "ISP_USER.h"

#define DetectPin   				PB0
